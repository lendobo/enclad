Matrix
======
Matrix class

.. automodule:: diffupy.matrix
   :members:
