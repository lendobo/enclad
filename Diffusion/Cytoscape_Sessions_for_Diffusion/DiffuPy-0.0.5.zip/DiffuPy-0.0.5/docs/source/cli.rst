Command Line Interface
======================
DiffuPy Command Line Interface

.. click:: diffupy.cli:main
   :prog: diffupy
   :show-nested:
