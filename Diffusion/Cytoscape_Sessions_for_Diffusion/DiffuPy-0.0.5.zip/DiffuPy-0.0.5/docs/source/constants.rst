Constants
=========
.. automodule:: diffupy.constants
   :members:
