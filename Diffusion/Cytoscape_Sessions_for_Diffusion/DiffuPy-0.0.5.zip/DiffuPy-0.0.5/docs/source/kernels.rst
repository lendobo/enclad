Kernel
======
.. automodule:: diffupy.kernels
   :members:
