# -*- coding: utf-8 -*-

"""Entrypoint module for ´python -m diffupy´."""

from .cli import main

if __name__ == '__main__':
    main()
