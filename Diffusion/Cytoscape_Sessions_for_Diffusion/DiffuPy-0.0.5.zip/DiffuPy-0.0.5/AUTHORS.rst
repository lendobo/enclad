Authors
=======
- `Josep Marín Llaó <https://github.com/jmarinllao>`_. Responsible of the Python adaptation hereby provided.
- `Sergi Picart Armada <https://github.com/SergiPicart>`_. Algorithm engineer with the development of the R version diffuStats.
- `Daniel Domingo Fernández <https://github.com/ddomingof>`_. Supervision.