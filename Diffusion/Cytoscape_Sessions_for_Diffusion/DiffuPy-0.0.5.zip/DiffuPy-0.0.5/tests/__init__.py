# -*- coding: utf-8 -*-

"""Diffupy tests."""
